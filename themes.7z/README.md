"# emesh" 

C:\xampp\htdocs\www\renovatio\emesh\wp-content\themes

took wp-content folder into 7z

db dup in zip

next time gitignore from root brother (:


brief 1:
https://docs.google.com/document/d/1FkJGi7V63QpWQMhzk3-vB__NV7EaVl9KtSY4Kj4NfJQ/edit

client folder:
https://drive.google.com/drive/u/0/folders/1LYQNYokdi9UFXCKwlra8Jv_QxjcZgnPJ


