<a id="hamburger-icon" href="#" title="Menu">
  <span class="line line-1"></span>
  <span class="line line-2"></span>
  <span class="line line-3"></span>
</a>
